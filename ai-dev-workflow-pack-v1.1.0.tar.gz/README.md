# AI Developer Workflow Pack

Premium **CLAUDE.md** templates, MCP server configurations, and slash commands for Claude Code and AI-assisted development.

---

## What's Included

### 5 Framework Templates (CLAUDE.md)

| Template | Stack | Best For |
|----------|-------|----------|
| **Next.js 15** | App Router, Prisma, SQLite, NextAuth, Stripe, shadcn/ui | Full-stack SaaS |
| **FastAPI** | SQLAlchemy, Pydantic, Alembic, pytest | Python backends |
| **Express + Prisma** | Node.js, Prisma, Zod, Vitest, Docker | REST APIs |
| **Rust + Axum** | SQLx, Tokio, Serde, Tower, tracing | High-perf services |
| **React + Vite** | TanStack Router, Tailwind, Vitest, Storybook | Frontend SPAs |

### 5 MCP Server Configurations

| MCP Server | What It Does |
|-----------|-------------|
| **GitHub** | PR review, issues, search repos, read files |
| **Database** | PostgreSQL/MySQL queries from Claude |
| **File System** | Safe read/write with permission boundaries |
| **Web Search** | Search the web from your terminal |
| **Browser** | Headless browser testing and scraping |

### 5 Custom Slash Commands

| Command | Description |
|---------|-------------|
| `review-code.py` | Full security + quality code review |
| `add-tests.py` | Auto-generate Vitest/pytest test suite |
| `db-migrate.py` | Create and review database migrations |
| `deploy-check.py` | Pre-deployment readiness checklist |
| `generate-changelog.py` | Generate CHANGELOG.md from git history |

---

## Quick Start

```bash
# 1. Pick your framework template
cp templates/nextjs-sqlite/CLAUDE.md /path/to/your/project/CLAUDE.md

# 2. (Optional) Copy MCP configs
cp mcp-configs/*.json /path/to/your/project/.claude/

# 3. Start coding
cd /path/to/your/project
claude
```

---

## Pricing

| Tier | Price | Includes |
|------|-------|----------|
| **Starter** | **$10** | 3 templates + 2 MCP configs |
| **Pro** | **$25** | All 5 templates + all MCP configs + 3 commands |
| **Enterprise** | **$50** | Full pack + custom template tailored to your stack |

---

## How to Buy

1. PayPal: shelly@example.com
2. Buy Me a Coffee: [your-link]
3. GitHub Sponsors: [your-profile]

---

## License

MIT - free to use, modify, and share.
